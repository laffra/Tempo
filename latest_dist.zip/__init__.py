import main

def run():
  main.run()